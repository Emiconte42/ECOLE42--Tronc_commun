#ifndef CURE_HPP
#define CURE_HPP

#include <iostream>
#include <string>
#include "AMateria.hpp"

/*
	Un sort de soin : il affiche * heals bob's wounds *.
	CLASSE CONCRETE :
		- Pas de =0
		- Une classe qu'on peut creer avec new
		- Toutes les fonctions ont du codes
		- Peut heriter d'interface, de classe concrete ou abstraite
*/

class Cure : public AMateria
{
	
};

#endif