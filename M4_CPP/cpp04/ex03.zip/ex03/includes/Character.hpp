#ifndef CHARACTER_HPP
#define CHARACTER_HPP

#include <iostream>
#include <string>
#include "ICharacter.hpp"

/*
	Le vrai heros : 
	il a un nom et un sac de 4 Materias, et il fait ce que promet ICharacter.
	CLASSE CONCRETE :
		- Pas de =0
		- Une classe qu'on peut creer avec new
		- Toutes les fonctions ont du codes
		- Peut heriter d'interface, de classe concrete ou abstraite

*/

class Character : public ICharacter
{

};

#endif