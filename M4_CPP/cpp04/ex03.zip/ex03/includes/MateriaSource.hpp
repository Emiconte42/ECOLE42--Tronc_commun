#ifndef MATERIASOURCE_HPP
#define MATERIASOURCE_HPP

#include <iostream>
#include <string>
#include "AMateria.hpp"
#include "IMateriaSource.hpp"

/*
	Le vrai livre de recettes :
	il garde jusqu'a 4 modeles et fabrique des copies neuves a partir d'un mot ("ice").
	CLASSE CONCRETE :
		- Pas de =0
		- Une classe qu'on peut creer avec new
		- Toutes les fonctions ont du codes
		- Peut heriter d'interface, de classe concrete ou abstraite
*/

class MateriaSource : public IMateriaSource
{

};

#endif